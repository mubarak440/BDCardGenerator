using HelloWorld; // add this

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// DI Registeration - Add this
builder.Services.AddSingleton<IProductRepository, ProductRepository>(); 


var app = builder.Build();

// Configure the HTTP request pipeline.
// Configure the HTTP request pipeline.
//if (!app.Environment.IsDevelopment())
//{
//    app.UseExceptionHandler("/Home/Error");
//}

// ==== For Exercise ====
// Note: can just call on ("/Error") as by default it goes to the index
// of Error Controller to call the action
app.UseExceptionHandler("/Error/Index");



app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
