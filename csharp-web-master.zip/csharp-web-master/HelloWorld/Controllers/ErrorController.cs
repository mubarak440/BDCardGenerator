﻿using HelloWorld.Models; 
using Microsoft.AspNetCore.Mvc; // Add
using System.Diagnostics; // Add
using Microsoft.AspNetCore.Diagnostics; // Add


// moved the Error action to this Error Controller
namespace HelloWorld.Controllers
{
    public class ErrorController : Controller
    {
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Index() // rename to Index
        {
            var exceptionHandlerPathFeature =
        HttpContext.Features.Get<IExceptionHandlerPathFeature>();

            var msg = exceptionHandlerPathFeature.Error.Message;

            var model = new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier,
                Message = msg,
            };

            // Note: We want the Error Page - not the index page
            return View("Error",model);
        }
    }
}
