﻿using HelloWorld.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.AspNetCore.Diagnostics;

namespace HelloWorld.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private IProductRepository productRepository;

        public HomeController(ILogger<HomeController> logger, IProductRepository productRepository)
        {
            this.productRepository = productRepository;
            _logger = logger;
        }

        public IActionResult Index()
        {
            // create a divide by zero exception to happen
            //int x = 1;  // add me
            //x = x / (x - 1); // add me

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

       //=== Note: For exception handling , we moved the 
       // Error method to another Controller, called ErrorController ===

        [HttpGet]
        public IActionResult RsvpForm()
        {
            return View();
        }

        [HttpPost]
        public IActionResult RsvpForm(GuestResponse guestResponse)
        {
            if (ModelState.IsValid)
            {
                return View("Thanks", guestResponse);
            }
            else // stay on the page if error validation happens
            {
                return View();
            }
        }

        // For product view
        [HttpGet]
        public IActionResult Product()
        {
            return View(productRepository.Products.First());
        }

        // for products collection

        [HttpGet]
        public IActionResult Products()
        {
            return View(productRepository.Products);
        }

    }
}